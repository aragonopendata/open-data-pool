<html>
<?php
$ArrayIps = array(
    // Importante no colocar la IP del proxy Inverso en el Array si no, cualquiera podra borrar caches de la Web App.
    '127.0.0.1',
    '::1',
    '151.182.127.4'
);

if (isset($_SERVER['REMOTE_ADDR'])) {
    if (in_array($_SERVER['REMOTE_ADDR'], $ArrayIps)) {
        limpiarCaches();
    }
}



if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $IParray = array_values(array_filter(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])));
    
    $longitudIParray = count($IParray);
    for ($i = 0; $i < $longitudIParray; $i++) {
        
        if (in_array($IParray[$i], $ArrayIps)) {
            limpiarCaches();
        }
        
    }
    
}


if (in_array($_SERVER['REMOTE_ADDR'], $ArrayIps)) {
    limpiarCaches();
}


Function AccesoDenegado()
{
    header('HTTP/1.0 403 Forbidden');
    echo 'You are not allowed to access this file.<br>No tienes permiso para acceder a este archivo.<br>Su intento de acceso quedo registrado en el sistema.';
    exit();
}


function limpiarCaches()
{
    echo "<br>" . exec(' /usr/bin/gzip -9 $(/usr/bin/find  /var/www/html/web/publicacion/Procesados |grep log*)');
    die("<br>Logs Comprimidos");
}
?>
</html>
