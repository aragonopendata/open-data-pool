<html>
<?php
echo "<br>". exec ("chmod 777 -R /var/www/html2/");
echo "<br>". exec ("chmod 777 -R /var/www/html/");
echo "<br>". exec ("rm -rf /var/www/html2/app/cache/pro~/*");
echo "<br>". exec ("rm -rf /var/www/html/app/cache/pro~/*");
echo "<br>". exec ("/usr/bin/php /var/www/html/app/console cache:clear --env=dev");
echo "<br>". exec ("/usr/bin/php /var/www/html/app/console cache:clear --env=prod");
echo "<br>". exec ("/usr/bin/php /var/www/html2/app/console cache:clear --env=dev");
echo "<br>". exec ("/usr/bin/php /var/www/html2/app/console cache:clear --env=prod");
echo "<br>". exec ("/usr/bin/php /var/www/html2/app/console  doctrine:cache:clear-metadata  --env=prod");
echo "<br>". exec ("/usr/bin/php /var/www/html2/app/console  doctrine:cache:clear-query   --env=prod");
echo "<br>". exec ("/usr/bin/php /var/www/html2/app/console doctrine:cache:clear-result --env=prod");
echo "<br>". exec ("/usr/bin/php /var/www/html2/app/console  doctrine:cache:clear-metadata  --env=dev");
echo "<br>". exec ("/usr/bin/php /var/www/html2/app/console  doctrine:cache:clear-query   --env=dev");
echo "<br>". exec ("/usr/bin/php /var/www/html2/app/console doctrine:cache:clear-result --env=dev");
echo "<br>". exec ("/usr/bin/php /var/www/html/app/console  doctrine:cache:clear-metadata  --env=prod");
echo "<br>". exec ("/usr/bin/php /var/www/html/app/console  doctrine:cache:clear-query   --env=prod");
echo "<br>". exec ("/usr/bin/php /var/www/html/app/console doctrine:cache:clear-result --env=prod");
echo "<br>". exec ("/usr/bin/php /var/www/html/app/console  doctrine:cache:clear-metadata  --env=dev");
echo "<br>". exec ("/usr/bin/php /var/www/html/app/console  doctrine:cache:clear-query   --env=dev");
echo "<br>". exec ("/usr/bin/php /var/www/html/app/console doctrine:cache:clear-result --env=dev");
echo "<br>". exec ("chmod 777 -R /var/www/html2/");
echo "<br>". exec ("chmod 777 -R /var/www/html/");
echo "<br>". exec ("rm -rf /var/www/html2/app/cache/pro~/*");
echo "<br>". exec ("rm -rf /var/www/html/app/cache/pro~/*");
?>
</html>
