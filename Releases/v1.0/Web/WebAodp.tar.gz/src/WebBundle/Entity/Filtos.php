<?php
namespace WebBundle\Entity;;

use WebBundle\Entity\Navegacion;
use ApiRest\AodPoolBundle\Entity\Facetas;

use WebBundle\Controller\Utility\Trazas;

//defino las url para realizar las consultas del paso1 (obtener los rftypes y cada cantador del los mismos)
//define("FILTROMUNICIPIO","ei2a:location <http://opendata.aragon.es/pool/municipio/%s> . ");
define("FILTROMUNICIPIO","?s wgs84_pos:location ?location . ?location dc:identifier '%s' . ");
define("FILTROCOMARCA","?s wgs84_pos:location ?location . ?location dc:identifier '%s' . ");
define("FILTROPROVINCIA","?s wgs84_pos:location ?location . ?location dc:identifier '%s' . ");
define("FILTROENTIDAD","?s rdf:type <%s> . ");
define("FILTROSUBENTIDAD","?s rdf:type <%s> . ?s dc:type '%s' .");
define("FILTROTEMA","?s rdf:type <%s> . ");
define("FILTROSUBTEMA","?s rdf:type <%s> . ");
define("FILTRODFTYPE","?s dc:type '%s' . ");
define("PREFIJOSDEFECTO","PREFIX ei2a:<http://opendata.aragon.es/def/ei2a#> PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>  PREFIX org:<http://www.w3.org/ns/org#> PREFIX foaf:<http://xmlns.com/foaf/0.1/> PREFIX dc:<http://purl.org/dc/elements/1.1/> PREFIX wgs84_pos:<http://www.w3.org/2003/01/geo/wgs84_pos#>");
define("QUERYRFDCUANTOS","%s select ?type count(?s) as ?contador from <%s> where { ?s rdf:type ?type . %s } group by ?type");

define("QUERYFACETA","%s select ?nombre count(?s) as ?contador from <%s> where { %s } group by ?nombre order by desc(count(?s))");
define("QUERYRESULTADOS1","%s select ?s ?type from <%s> where { ?s rdf:type ?type . %s } group by ?type");
define("QUERYRESULTADOS2","%s select ?s ?type ?date ?name from <%s> where { ?s rdf:type ?type. %s } order by %s(%s) LIMIT 10 OFFSET %s "); 
define("QUERYRESULTADOS2FILTROSUJETOS","filter(?s in (<%s>))");

define("CAMPO_FACETA_NOMBRE","?nombre");
define("CAMPO_RESULTADO_NOMBRE","?descripcion ");
define("CAMPO_RESULTADO_FECHA","?fecha");


define("FACETA_TEMA","Temas");
define("FACETA_ENTIDAD","Tipos");
define("FACETA_PROVINCIA","Provincias");
define("FACETA_COMARCA","Comarcas");
define("FACETA_MUNICIPIO","Municipios");


//definio las distintas partes de los filtros
/*
define("TEMA","tem");
define("SUBTEMA","stem");
define("PROVINCIA","pro");
define("COMARCA","com");
define("MUNICIPIO","mun");
define("ENTIDAD","ent");
define("SUBENTIDAD","sent");
define("FROMTYPE","from");
define("FILTERS","filters");*/

class Filtos{
    
/**
 * Facetas
 * Clase para le gestión de facetas hacia virtuoso desde los parámetros get de entrada
 */
    
    //objeto de navegacion con los parámetros de entrada
    protected $navegacion;
    
    //objeto que lanzalas consultas sobre virtuoso
    protected $virtuoso;

    //objeto que lanzalas consultas sobre la tabla facetas en progresSQL
    protected $facetasDB;

    //objeto que lanzalas consultas sobre la tabla camposresultado en progresSQL
    protected $camposResultadoDB;

    //conjunto de facetas de salida
    protected $facetasResultado;

    //conjunto de resultados de salida
    protected $elementosResultado;

     //objeto que lanzalas consultas sobre la tabla temas en progresSQL
    protected $temasDB;
   
     //objeto que lanzalas consultas sobre la tabla entidades en progresSQL
    protected $entidadesDB;

    //objeto que lanzalas consultas sobre la tabla localdaades en progresSQL
    protected $localidadesDB;

    //total de resultados de salida
    protected $totalResultados;

    //clase de trazas
    protected $trazas=null;

    public function __construct($navegacion, $virtuoso, $facetasDB, $camposResultadoDB, $temasDB, $entidadesDB, $directoryPath) {
        $this->navegacion = $navegacion;
        $this->virtuoso = $virtuoso;
        $this->facetasDB = $facetasDB;
        $this->temasDB = $temasDB;
        $this->entidadesDB = $entidadesDB;
      //  $this->localidadesDB = $localidadesDB;
        $this->camposResultadoDB = $camposResultadoDB;

        $this->trazas = new Trazas($directoryPath);
        $this->trazas->setClase("Filtos");
    }
    
    public function getFacetasResultado(){ 
        return $this->facetasResultado;
    }
    
    public function getElementosResultado(){

        return $this->elementosResultado;
    }

    public function getTotalResultados(){

        return $this->totalResultados;
    }

    public function ProcesaFacetas(){
        $rfdTypes = $this->DameConsulta(QUERYRFDCUANTOS);
        $this->totalResultados = 0;
        foreach ($rfdTypes as $type) {
            $this->totalResultados += $type['contador'];
        }
        $this->facetasResultado= array();
        if (count($rfdTypes)>0) { 
            $facetasporrfdtype = $this->facetasDB->GetFacetasbyDefault();
           /* if (count($rfdTypes)>1) {
                $facetasporrfdtype = $this->facetasDB->GetFacetasbyDefault();
            } else {
                $facetasporrfdtype = $this->facetasDB->GetFacetasbyRfdType($rfdTypes[0]['type']);
            }*/
            foreach ($facetasporrfdtype  as $facetaRfd) {
                //primero voy por las facetas si dctype la vacias y comunes
                if (empty($facetaRfd['DcType'])){
                    $facetavirtuoso = $this->DameFaceta($facetaRfd);
                    $facetaweb = $this->DameFacetaWeb($facetavirtuoso,$facetaRfd);
                    $this->facetasResultado[] = $facetaweb;
                }
            }
            $arrayFilters  = $this->navegacion->getFilters();
            foreach ($facetasporrfdtype  as $facetaRfd) {
                if (!empty($facetaRfd['DcType'])){
                    foreach ($arrayFilters as $filter) {
                        $dctype = $this->entidadesDB->GetDcTypeByName($filter['Valor']);
                        if ($facetaRfd['DcType']==$dctype){
                            $facetavirtuoso = $this->DameFaceta($facetaRfd);
                            $facetaweb = $this->DameFacetaWeb($facetavirtuoso,$facetaRfd);
                            $this->facetasResultado[] = $facetaweb;
                        }
                    }
                }
            }
        }    
    }

    public function ProcesaResultados($paginacion,$order,$campoOrder){

            
        $resultadosWeb = array();
        $rfdTypes = $this->DameConsulta(QUERYRESULTADOS1);
      /*  "RdfType"
        "OrderBy" 
        "FieldDate" 
        "PrefijoFieldDate" ,
        "FieldName" 
        "PrefijoFieldName"
        "FieldSearch" 
        "PrefijoFieldSearch"*/
        $filtros ="";
        $cuenta = 0;
        $prefijos= PREFIJOSDEFECTO;
        $from = $this->virtuoso->getIsqlDb();
        foreach ($rfdTypes as $rfdType) {
            $parametrosResultados = $this->camposResultadoDB->GetCamposbyRfdType($rfdType['type']);
            if (!empty($parametrosResultados[0]['PrefijoFieldDate'])){
                $prefijos = $prefijos . " " . $parametrosResultados[0]['PrefijoFieldDate'];
            }
            if (!empty($parametrosResultados['PrefijoFieldName'])){
                $prefijos = $prefijos . " " . $parametrosResultados[0]['PrefijoFieldName'];
            }
            
            $CampoFecha = $parametrosResultados[0]['FieldDate'];
            $CampoNombre = $parametrosResultados[0]['FieldName'];
            if (!empty($CampoFecha )){
                $CampoFecha = $this->DameFiltro($CampoFecha,"",'?date');
            }
            if (!empty($CampoNombre )){
                $CampoNombre = $this->DameFiltro($CampoNombre,"",'?name');
            }

            $filtroSujetos= sprintf(QUERYRESULTADOS2FILTROSUJETOS,$rfdType['s']);
            $filtroUnion = sprintf("{ optional {%s}  %s %s } UNION ",$CampoFecha , $CampoNombre, $filtroSujetos);
            $filtros.= $filtroUnion;
        }
        $filtros = substr($filtros, 0, strlen($filtros) - 6);
        
        if (intval($paginacion)>0){
            $paginacion = 10 * intval($paginacion) -1;
        } else {
            $paginacion = 0;
        }
        if (empty($campoOrder)){
            $campoOrder = "?type";
        }
        
        $query = sprintf(QUERYRESULTADOS2,$prefijos,$from, $filtros, $order,$campoOrder,$paginacion);
        $this->trazas->LineaInfo("ProcesaResultados",$query);
        $resultados = $this->virtuoso->DameConsultaWeb($query,"SUJETOS");
        $Resutadoweb = $this->DameResultadosWeb($resultados);
        $this->elementosResultado = $Resutadoweb;     
    }

    private function DameConsulta($plantilla){
       $prefijos = PREFIJOSDEFECTO;
       $from = $this->virtuoso->getIsqlDb();
       $filtros = "";     
       $filtrosArray = $this->DameFiltrosDeNavegacion();
       foreach ($filtrosArray as $filtro) {
            foreach ($filtro as $key => $value) {
                $filtros.= $value;
            } 
       }
       $query = sprintf($plantilla,$prefijos,$from,$filtros); 
       $this->trazas->LineaInfo("DameConsulta",$query);
       $rfdtypes = $this->virtuoso->DameConsultaWeb($query,"SUJETOS");
       return $rfdtypes;   
    }

    private function DameResultado($facetaRfd){

        $prefijos = PREFIJOSDEFECTO;
        //recojo el from
        $from = $this->virtuoso->getIsqlDb();
        //recojo campos fecha y nombre de la entidad
        $campoFecha = $facetaRfd->getgetFieldDate(); 
        $camponombre = $facetaRfd->getFieldName(); 

        //inicilizo la cadena de los filtros
        $filtros.= sprintf(" %s %s .",CAMPO_RESULTADO_FECHA,$campoFecha);
        $filtros.= sprintf(" %s %s .",CAMPO_RESULTADO_NOMBRE,$camponombre);

        //recojo el array de los filtros
        $filtrosarray = $this->DameFiltrosDeNavegacion();
        //por cada filtro encontrado
        foreach ($filtrosArray as $filtro) {
            foreach ($filtro as $key => $value) {
              $filtros.= $value;
            }
        }
        //Creo la query con la plantilla
        $query = sprintf(QUERYRESULTADOS, $prefijos,$from, $filtros);
        //llamo a virtuoso
        $this->trazas->LineaInfo("DameResultado",$query);
        $resultados = $this->virtuoso->DameConsultaWeb($query,"SUJETOS");

        return $resultados;       
    }

    //funcion que devuelve las facetas dados los rfdtypes
    private function DameFaceta($facetaRfd){
        //inicilalizo el array de salida
        $facetas = array();  
        
        //GetNameByRftype //GetNameByDcType   
        //inicializo los encabezados por defecto  
        $prefijos = PREFIJOSDEFECTO;
        if (!empty($facetaRfd['PrefijoFaceta'])){
            $prefijos =  $prefijos ." " . trim($facetaRfd['PrefijoFaceta']);
        }
        //recojo el from
        $from = $this->virtuoso->getIsqlDb();
        //inicilizo la cadena de los filtros
        $filtros = "";
        //recojo el array de los filtros
        $filtrosarray = $this->DameFiltrosDeNavegacion();
        //por cada filtro encontrado
        $filtroEncontrado = false;
        foreach ($filtrosarray as $filtro) {
            foreach ($filtro as $key => $value) {
                $filtros.= $value;
            }
        }
        $filtros.= $this->DameFiltro($facetaRfd['Faceta'],$facetaRfd['Condition'],CAMPO_FACETA_NOMBRE);
        
        //Creo la query con la plantilla
        $query = sprintf(QUERYFACETA,$prefijos,$from,$filtros);
        //llamo a virtuoso
        $this->trazas->LineaInfo("DameFaceta",$query);
        $facetas = $this->virtuoso->DameConsultaWeb($query,"SUJETOS");
            
        switch ($facetaRfd['NameHead']) {
            case FACETA_TEMA:
                $facetasTemporal = Array();
                foreach ($facetas as $faceta) {
                    # code...
                    $rfdtype = $faceta['nombre'];
                    $rfdtype  = $this->temasDB->GetNameByRftype($rfdtype);
                    if(!empty($rfdtype)) {
                        $faceta['nombre']= $rfdtype;
                        $facetasTemporal[] = $faceta;
                    }
                } 
                $facetas = $facetasTemporal;
                break;
            case FACETA_ENTIDAD:
                $facetasTemporal = Array();
                foreach ($facetas as $faceta) {
                    # code...
                    $dctype = $faceta['nombre'];
                    $dctype  = $this->entidadesDB->GetNameByDcType($dctype);
                    if(!empty($dctype)) {
                        $faceta['nombre']= $dctype;
                        $facetasTemporal[] = $faceta;
                    }
                } 
                $facetas = $facetasTemporal;
            break;          
        }
        return $facetas;   
    }
 
    //funcion que devuelve el nombre de la faceta (titulo) dado el nombre del parametro get de trada de la misma
    //se utiliza para el segundo paso recoger las facetas dados los rftypes encontrados
    //ya que 
    private function DameNombreFacetaPorParametroGet($parametro){
      $NombreFaceta="";
      switch ($parametro) {
            case TEMA:
                $NombreFaceta = FACETA_TEMA;
                break;
            case SUBTEMA:
                $NombreFaceta = FACETA_TEMA;
                break;  
            case ENTIDAD:
                $NombreFaceta = FACETA_ENTIDAD;
                break;
            case SUBENTIDAD:
                $NombreFaceta = FACETA_ENTIDAD;
                break;
            case PROVINCIA:
                $NombreFaceta = FACETA_PROVINCIA;
                break;
            case COMARCA:
                $NombreFaceta = FACETA_COMARCA;
                break; 
            case MUNICIPIO:
                $NombreFaceta = FACETA_MUNICIPIO;
                break;             
          default:
      }
      return $NombreFaceta;
    }

    /**
	 * Función que dada una cadena de texto devuelve el filtro o filtros con formato sparql
	 * Los filtos pueden estar anidados por @ y condicionados con $ para el reverso
     * Tambien admite un campo condition que es otro filtro anidado con el mismo origen que $filter por lo que no hay que repetirlo
	 */
	public function DameFiltro($filter,$condition,$valor){
		$filtro = "";

        //conpruebo que existe operador '@' (filtros anidados)
        $pos = strpos($filter, "@");
        //si no hay es una condicion simple 
        if ( $pos === FALSE) {
                $filtro  = sprintf("?s %s %s .",$filter, $valor);
        } else {
            //en caso contrario miro si existe operador $ (condicion reverso para la primara condición)
            $condolar = (boolean)(strpos($filter, "$")===0);
            //separo los anidamientos por '@'
            $filterConditionPart = explode("@",$filter);
            $count = 0;
            //por cada uno de ellos creo la condicicón anidada
            foreach ($filterConditionPart as $filterCondition) {
                //en caso que sea la primara condiciopn y tenga reverso cruzo las condiciones
                if ($count==0){
                    if ($condolar) {
                        $filtro .=  sprintf("?s%s %s ?s . ",$count, $filterCondition);
                    } else {
                        //si no creo el anidamiento normalmente
                        $filtro .=  sprintf("?s %s ?s%s . ", $filterCondition, $count);
                    }
                } else {
                    $filtro .=  sprintf("?s%s %s ?s%s . ",$count-1, $filterCondition, $count);		
                }
                $count++;
            }
            //repplazo la ultima variable con el valor a buscar
            $ultimo = sprintf("?s%s",$count-1);
            $filtro = str_replace($ultimo,$valor,$filtro);
            
            //si hay filtro condicion
            if (!empty($condition)) {
                //recojo las partes
                $filterConditionPart = explode("@",$condition);
                $count = 0;
                $filtroCondicion ="";
                //por cada uno de ellos creo la condicicón anidada
                foreach ($filterConditionPart as $filterCondition) {
                    //en caso que sea la primara condicion en el campo condition hay que ponerla ya que ya
                    //se ha incluido en el filtro
                    if ($count>0){
                        //separo el campo del valor por '='
                        $campoValor = explode("=",$filterCondition);
                        if (count($campoValor)==2) {
                            $filtroCondicion =  sprintf(" ?s%s %s %s . ",$count-1, $campoValor[0], $campoValor[1]);
                        }		
                    }
                    $count++;
                }
                $filtro = $filtro . $filtroCondicion;
            }
        }
        return $filtro;
    }
    
    //función que devuelve un array con los filtros formato virtuoso con todos los parámetros
    //recogidos en el objeto navegacion (obtien los datos de los parámetros de la url (get)
    private function DameFiltrosDeNavegacion(){
        //inicilizo el array de respuesta
        $filtros=array();
        //por cada uno delos parametros pregunto si exite 
        if (!(empty($this->navegacion->getProvinciaCode()))) {
            //si existe parseo el filtro (formato virtuoso), con su plantilla correspondiente
            $filtro = sprintf(FILTROPROVINCIA, $this->navegacion->getProvinciaCode());
            //añado el filtro al array con su clave correspondiente
            $filtros[PROVINCIA] = array(FACETA_PROVINCIA=>$filtro);
        } 
        if (!(empty($this->navegacion->getComarcaCode()))) {
            $filtro = sprintf(FILTROCOMARCA,$this->navegacion->getComarcaCode());
            $filtros[COMARCA] = array(FACETA_COMARCA=>$filtro);
        } 
        if (!(empty($this->navegacion->getMunicipioCode()))) {
            $filtro = sprintf(FILTROMUNICIPIO,$this->navegacion->getMunicipioCode());
            $filtros[MUNICIPIO] = array(FACETA_MUNICIPIO=>$filtro);
        } 

        if (!(empty($this->navegacion->getSubTemaCode()))) {
               
            $filtro = sprintf(FILTROSUBTEMA,$this->navegacion->getRdfTypeTema());
            $filtros[SUBTEMA] = array(FACETA_TEMA=>$filtro); 
        } 

        if ((empty($this->navegacion->getSubTemaCode()))) {
            if (!(empty($this->navegacion->getTemaCode()))) {
                $filtro = sprintf(FILTROTEMA,$this->navegacion->getRdfTypeTema());
                $filtros[TEMA] = array(FACETA_TEMA=>$filtro);
            } 
        }
        if (!(empty($this->navegacion->getSubEntidadCode()))) {
            $filtro = sprintf(FILTROSUBENTIDAD,$this->navegacion->getRdfTypeEntidad(), $this->navegacion->getDcTypeEntidad());
            $filtros[SUBENTIDAD] = array(FACETA_ENTIDAD=>$filtro);
        }  

        if ((empty($this->navegacion->getSubEntidadCode()))) {
            if (!(empty($this->navegacion->getEntidadCode()))) {
                $filtro = sprintf(FILTROENTIDAD,$this->navegacion->getRdfTypeEntidad());
                $filtros[ENTIDAD] = array(FACETA_ENTIDAD=>$filtro);
            } 
        }  
        if (count($this->navegacion->getFilters()>0)) {
           $stringFiltres="";
           $arrayFilters  = $this->navegacion->getFilters();
           foreach ($arrayFilters as $filter) {
                $valor = $this->DameValorFaceta($filter['NameHead'],$filter['Valor'],$filter['Faceta']);
			    $stringFiltres .= $this->DameFiltro($filter['Faceta'],"", $valor) . " ";
		   }
           $filtros[FILTERS] = array("AÑADIDOS"=>$stringFiltres); 
        } 
        return  $filtros;
    }
    
    //Funcion que rehace el filtro ya que el valor recogido en la segunda pasada es descriptivo y el filtro
    // valor sparql tambien cambia
    private function DameValorFaceta($namehead,$valor,$faceta){
        $nuevovalor = "";
        switch ($namehead) {
            //Municipios, Cpmarcas Temas Tipos Sede Provincias
            case 'Tipos':
                $nuevovalor = $this->entidadesDB->GetDcTypeByName($valor);
                break;
            case 'Temas':
                break;
            case 'Comarcas':
                break;
            case 'Provincias':
                //$nuevovalor = $this->entidadesDB->GetDcTypeByName($valor);
                break;
            default:
                $nuevovalor = $valor;
                break;
        }
        $protocolo = (isset($_SERVER['HTTPS'])) ? "https" : "http";
        if (strpos($protocolo,$valor) === False) {
            $nuevovalor = sprintf("'%s'",$nuevovalor);
        }
        return $nuevovalor;
    }

    //función que devuelve una cadena con los filtros formato virtuoso del parametro
    //filters pasado por la url (get)
    private function DameFiltrosDeParametro($filtrosparametro){
        $stringFiltres = "";
        $arrayFilters = explode("|",$filtrosparametro);
        if (count($arrayFilters)>0) {
            //primero creo las condiciones del filtro   
		   foreach ($arrayFilters as $filter) {
			    $stringFiltres .= $this->virtuoso->DameFiltro($filter);
		   }
        }
        return $stringFiltres;
    }
    
  
    //funcion que compone el array de salida para la web de la faceta
    private function DameFacetaWeb($facetaVirtuoso,$facetaRfd){
        $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $filtro = (isset($_GET["filt"])) ? $_GET["filt"] : "";
        $pos = strpos($actual_link,"filt=");
        if ($pos) {
            $actual_link = substr($actual_link,0, $pos);
        } else {
            $actual_link = $actual_link . "&";
        }

        $facetaWeb = array();
        if (count($facetaVirtuoso)>0) {
            $facetaArray = array();
            foreach ($facetaVirtuoso as $faceta) {
                $filtro = (isset($_GET["filt"])) ? $_GET["filt"] : "";
                $filtroUrl = $this->DameFacetaFiltro($faceta['nombre'],$facetaRfd,$filtro);      
                $url = $actual_link .  $filtroUrl;
                if ($faceta['contador']>0) {
                    $facetaArray[] = array("href"=>$url, "name"=>$facetaRfd['NameHead'],"title"=>$faceta['nombre'], "count"=>$faceta['contador']);
                }
            } 
            $id = "id".$facetaRfd['NameHead'];
            $boxid = "idfaceta_". $facetaRfd['NameHead'] . "_boxid";
            $facetaWeb = array("id"=>  $id , "boxid"=>$boxid, "title"=>$facetaRfd['NameHead'], "facetaArray" => $facetaArray);
        }
        return  $facetaWeb;
    }

    private function DameFacetaFiltro($valor,$facetaRfd,$filt)
    {   
        $filtro ="";
        $filtroFinal="";
        $protocolo = (isset($_SERVER['HTTPS'])) ? "https" : "http";
        if (strpos($protocolo,$valor) === 0) {
            $valor = sprintf("<%s>",$valor);
        }
        $filtroComp = sprintf("%s__%s__%s__%s",$facetaRfd['NameHead'],$facetaRfd['Faceta'],$valor,$facetaRfd['PrefijoFaceta']);
        $ponfiltro = true;
        if (!empty($filt)) {
            $ponfiltro = (strpos($filtroComp,$filt)===FALSE);
        }
        if ($ponfiltro) {
            $filtro = sprintf("%s__%s__%s__%s",$facetaRfd['NameHead'],$facetaRfd['Faceta'],$valor,$facetaRfd['PrefijoFaceta']);
            if (!empty($filt) ) {      
                $filtroFinal .= "filt=" . $filt. "|" . $filtro;           
            } else {
                $filtroFinal= "filt=" .  $filtro;
            }

        } else {
            $filtroFinal= "filt=" . $filt;
        }
        return  $filtroFinal ;
    }



    //funcion que compone el array de salida para la web de los resultados
    private function DameResultadosWeb($resultadosVirtuoso){
        $resources = array();
        $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $urlcompose = explode("?",$actual_link);

        foreach ($resultadosVirtuoso as $resultado) {
            $tipo =  $this->entidadesDB->GetNameByRfdType($resultado['type']);
            $date = "Sin fecha";
            $name = "Sin Nombre";
            if (isset($resultado['date'])) {
                $date = $resultado['date'];
            }
            if (isset($resultado['name'])){
                $name = $resultado['name'];
            }
            $ruta = str_replace("filtros","detalles",$urlcompose[0]);
            $url = sprintf("%s?url=%s&%s",$ruta, $resultado['s'],$urlcompose[1]);
            $resources[] = array("tipo"=>$tipo,"fecha"=>$date,"descripcion"=>$name,"url"=>$url);
        }
        return  $resources;
    }


}
