<?php

namespace ApiRest\AodPoolBundle\Repository;

use Doctrine\ORM\EntityManager;
use ApiRest\AodPoolBundle\Entity\RfdConfiguracion;
use Symfony\Component\Yaml\Yaml;

/** 
 * Repositorio de las operaciones a BD de rfdConfiguracion (los esquemas web)
*/
class RfdConfig
{
    /**
     * Gestor doctrine
     */
    private $em = null;

    protected function configure()
    {
        $this->setName('Repository_RfdConfig') ;
    }


    public function __construct($doctrine) {
        $this->em = $doctrine;
    }

    function GetRfdConfiguraciones() {
        $rfdConfiguracionSol = array();

        $consulta = $this->em->createQuery("SELECT t FROM ApiRestAodPoolBundle:RfdConfiguracion t 
                                      WHERE t.active = '1'  
                                      ORDER BY t.name ASC"); 
        $rfdConfiguraciones = $consulta->getResult();
        foreach ($rfdConfiguraciones as $rfdConfiguracion) { 
           $rfdConfiguracionSol[$rfdConfiguracion->getCode()] = $rfdConfiguracion->getName();
        }
        return $rfdConfiguracionSol;
    }

    function GetRfdConfiguracion($code) {
        $rfdConfiguracionSol = array();

        $consulta = $this->em->createQuery("SELECT t FROM ApiRestAodPoolBundle:RfdConfiguracion t 
                                      WHERE t.active = '1' and
                                            t.code = $code"); 
        $rfdConfiguraciones = $consulta->getResult();
        foreach ($rfdConfiguraciones as $rfdConfiguracion) { 
           $rfdConfiguracionSol[$rfdConfiguracion->getCode()]= Yaml::parse($rfdConfiguracion->getConfiguracion());  
        }
        $query = $rfdConfiguracionSol[20]['PanelCentral']['CampoValores']['CampoValor1']['Query'];
        foreach ($rfdConfiguracionSol[20]['PanelCentral']['CampoValores'] as $campovalor) {
            if ($campovalor['Tipo']=='Virtuoso') {
               $query = $campovalor['Query'];
            }
        }
        return $rfdConfiguracionSol;
    }

    function GetRfdConfiguracionbyName($name) {
        $rfdConfiguracionSol = array();

        $consulta = $this->em->createQuery("SELECT t FROM ApiRestAodPoolBundle:RfdConfiguracion t 
                                            WHERE
                                            t.name = '$name'"); 
        $rfdConfiguraciones = $consulta->getResult();
        foreach ($rfdConfiguraciones as $rfdConfiguracion) { 
           $rfdConfiguracionSol[$rfdConfiguracion->getCode()]= Yaml::parse($rfdConfiguracion->getConfiguracion());  
        }
        return $rfdConfiguracionSol;
    }
    

    function DeleteRfdConfiguracion($code) {
        $rfdConfiguracionSol = array();

        $consulta = $this->em->createQuery("DELETE FROM ApiRestAodPoolBundle:RfdConfiguracion t
                                            WHERE t.code = $code"); 
        $rfdConfiguraciones = $consulta->getResult();
        return $rfdConfiguracionSol;
    }

    function GetName($code) {
        $rfdConfiguracion= "";
        $consulta = $this->em->createQuery("SELECT t FROM ApiRestAodPoolBundle:RfdConfiguracion t 
                                      WHERE t.active = '1' and 
                                            t.code = $code"); 
        $query = $consulta->getResult();
        if (count($query)>0){
            $rfdConfiguracion = $query[0]->getName();
        }
        return $rfdConfiguracion;
    }

    function GetConfiguracionName($name) {
        $rfdConfiguracion= "";
        $consulta = $this->em->createQuery("SELECT t FROM ApiRestAodPoolBundle:RfdConfiguracion t 
                                            WHERE t.active = '1' and 
                                            t.name = $name"); 
        $query = $consulta->getResult();
        if (count($query)>0){
            $rfdConfiguracion = $query[0]->getConfiguracion();
        }
        return $rfdConfiguracion;
    }

    function GetConfiguracion($code) {
        $rfdConfiguracion= "";
        $consulta = $this->em->createQuery("SELECT t FROM ApiRestAodPoolBundle:RfdConfiguracion t 
                                      WHERE t.active = '1' and 
                                            t.code = $code"); 
        $query = $consulta->getResult();
        if (count($query)>0){
            $rfdConfiguracion = $query[0]->getConfiguracion();
        }
        return $rfdConfiguracion;
    }

    function SetRfdConfiguracion($nombe,$yml) {
        $rfdConfiguracion = new RfdConfiguracion();
        $slag = str_replace(" ", "_",$nombe);
        $slag = strtolower($slag);
        $rfdConfiguracion->setSlug($slag);
        $rfdConfiguracion->setName($nombe);
        $rfdConfiguracion->setConfiguracion($yml);
        $rfdConfiguracion->setActive(true);
       // $rfdConfiguracion->setCreated(date("Y-m-d"));
        $this->em->persist($rfdConfiguracion);
        $this->em->flush();
    }

}