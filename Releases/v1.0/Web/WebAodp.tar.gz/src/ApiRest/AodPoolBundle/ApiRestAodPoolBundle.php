<?php

namespace ApiRest\AodPoolBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ApiRestAodPoolBundle extends Bundle
{
}
