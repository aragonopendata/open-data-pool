<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes;

    public function __construct(RequestContext $context, LoggerInterface $logger = null)
    {
        $this->context = $context;
        $this->logger = $logger;
        if (null === self::$declaredRoutes) {
            self::$declaredRoutes = array(
        'portada' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'WebBundle\\Controller\\DefaultController::portadaAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'temas' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'WebBundle\\Controller\\DefaultController::temasAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/temas',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'lugares' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'WebBundle\\Controller\\DefaultController::lugaresAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/lugares',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'temasentidades' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'WebBundle\\Controller\\DefaultController::temasentidadesAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/temasentidades',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'entidades' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'WebBundle\\Controller\\DefaultController::entidadesAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/entidades',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'filtros' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'WebBundle\\Controller\\DefaultController::filtrosAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/filtros',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'resultados' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'WebBundle\\Controller\\DefaultController::resultadosAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/resultados',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'detalles' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'WebBundle\\Controller\\DefaultController::detallesAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/detalles',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'get_topics' => array (  0 =>   array (    0 => '_format',  ),  1 =>   array (    '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getTopicsAction',    '_format' => 'json',  ),  2 =>   array (    '_format' => 'xml|json|html',    '_method' => 'GET',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '.',      2 => 'xml|json|html',      3 => '_format',    ),    1 =>     array (      0 => 'text',      1 => '/api-consulta/topics',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'get_types' => array (  0 =>   array (    0 => '_format',  ),  1 =>   array (    '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getTypesAction',    '_format' => 'json',  ),  2 =>   array (    '_format' => 'xml|json|html',    '_method' => 'GET',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '.',      2 => 'xml|json|html',      3 => '_format',    ),    1 =>     array (      0 => 'text',      1 => '/api-consulta/types',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'get_query' => array (  0 =>   array (    0 => '_format',  ),  1 =>   array (    '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getQueryAction',    '_format' => 'json',  ),  2 =>   array (    '_format' => 'xml|json|html',    '_method' => 'GET',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '.',      2 => 'xml|json|html',      3 => '_format',    ),    1 =>     array (      0 => 'text',      1 => '/api-consulta/query',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'get_rdf' => array (  0 =>   array (    0 => '_format',  ),  1 =>   array (    '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getRdfAction',    '_format' => 'json',  ),  2 =>   array (    '_format' => 'xml|json|html',    '_method' => 'GET',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '.',      2 => 'xml|json|html',      3 => '_format',    ),    1 =>     array (      0 => 'text',      1 => '/api-consulta/rdf',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'nelmio_api_doc_index' => array (  0 =>   array (    0 => 'view',  ),  1 =>   array (    '_controller' => 'Nelmio\\ApiDocBundle\\Controller\\ApiDocController::indexAction',    'view' => 'default',  ),  2 =>   array (    '_method' => 'GET',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'view',    ),    1 =>     array (      0 => 'text',      1 => '/api-docs',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
    );
        }
    }

    public function generate($name, $parameters = array(), $referenceType = self::ABSOLUTE_PATH)
    {
        if (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}
