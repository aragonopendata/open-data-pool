<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);

        // portada
        if ('' === rtrim($pathinfo, '/')) {
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif (!in_array($this->context->getMethod(), array('HEAD', 'GET'))) {
                goto not_portada;
            } else {
                return $this->redirect($rawPathinfo.'/', 'portada');
            }

            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::portadaAction',  '_route' => 'portada',);
        }
        not_portada:

        // temas
        if ('/temas' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::temasAction',  '_route' => 'temas',);
        }

        // lugares
        if ('/lugares' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::lugaresAction',  '_route' => 'lugares',);
        }

        // temasentidades
        if ('/temasentidades' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::temasentidadesAction',  '_route' => 'temasentidades',);
        }

        // entidades
        if ('/entidades' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::entidadesAction',  '_route' => 'entidades',);
        }

        // filtros
        if ('/filtros' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::filtrosAction',  '_route' => 'filtros',);
        }

        // resultados
        if ('/resultados' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::resultadosAction',  '_route' => 'resultados',);
        }

        // detalles
        if ('/detalles' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::detallesAction',  '_route' => 'detalles',);
        }

        if (0 === strpos($pathinfo, '/api-')) {
            if (0 === strpos($pathinfo, '/api-consulta')) {
                if (0 === strpos($pathinfo, '/api-consulta/t')) {
                    // get_topics
                    if (0 === strpos($pathinfo, '/api-consulta/topics') && preg_match('#^/api\\-consulta/topics(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_get_topics;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_topics')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getTopicsAction',  '_format' => 'json',));
                    }
                    not_get_topics:

                    // get_types
                    if (0 === strpos($pathinfo, '/api-consulta/types') && preg_match('#^/api\\-consulta/types(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_get_types;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_types')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getTypesAction',  '_format' => 'json',));
                    }
                    not_get_types:

                }

                // get_query
                if (0 === strpos($pathinfo, '/api-consulta/query') && preg_match('#^/api\\-consulta/query(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_get_query;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_query')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getQueryAction',  '_format' => 'json',));
                }
                not_get_query:

                // get_rdf
                if (0 === strpos($pathinfo, '/api-consulta/rdf') && preg_match('#^/api\\-consulta/rdf(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_get_rdf;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_rdf')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getRdfAction',  '_format' => 'json',));
                }
                not_get_rdf:

            }

            // nelmio_api_doc_index
            if (0 === strpos($pathinfo, '/api-docs') && preg_match('#^/api\\-docs(?:/(?P<view>[^/]++))?$#sD', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_nelmio_api_doc_index;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'nelmio_api_doc_index')), array (  '_controller' => 'Nelmio\\ApiDocBundle\\Controller\\ApiDocController::indexAction',  'view' => 'default',));
            }
            not_nelmio_api_doc_index:

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
