<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === rtrim($pathinfo, '/')) {
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif (!in_array($this->context->getMethod(), array('HEAD', 'GET'))) {
                        goto not__profiler_home;
                    } else {
                        return $this->redirect($rawPathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }
                not__profiler_home:

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ('/_profiler/purge' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // portada
        if ('' === rtrim($pathinfo, '/')) {
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif (!in_array($this->context->getMethod(), array('HEAD', 'GET'))) {
                goto not_portada;
            } else {
                return $this->redirect($rawPathinfo.'/', 'portada');
            }

            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::portadaAction',  '_route' => 'portada',);
        }
        not_portada:

        // temas
        if ('/temas' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::temasAction',  '_route' => 'temas',);
        }

        // lugares
        if ('/lugares' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::lugaresAction',  '_route' => 'lugares',);
        }

        // temasentidades
        if ('/temasentidades' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::temasentidadesAction',  '_route' => 'temasentidades',);
        }

        // entidades
        if ('/entidades' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::entidadesAction',  '_route' => 'entidades',);
        }

        // filtros
        if ('/filtros' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::filtrosAction',  '_route' => 'filtros',);
        }

        // detalles
        if ('/detalles' === $pathinfo) {
            return array (  '_controller' => 'WebBundle\\Controller\\DefaultController::detallesAction',  '_route' => 'detalles',);
        }

        if (0 === strpos($pathinfo, '/api-')) {
            if (0 === strpos($pathinfo, '/api-consulta')) {
                if (0 === strpos($pathinfo, '/api-consulta/web/rfdconfiguracion')) {
                    // get_rfd_configuraciones
                    if (preg_match('#^/api\\-consulta/web/rfdconfiguracion(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_get_rfd_configuraciones;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_rfd_configuraciones')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getRfdConfiguracionesAction',  '_format' => 'json',));
                    }
                    not_get_rfd_configuraciones:

                    // get_rfd_configuracion
                    if (preg_match('#^/api\\-consulta/web/rfdconfiguracion/(?P<code>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_get_rfd_configuracion;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_rfd_configuracion')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getRfdConfiguracionAction',  '_format' => 'json',));
                    }
                    not_get_rfd_configuracion:

                    // delete_rfd_configuracion
                    if (preg_match('#^/api\\-consulta/web/rfdconfiguracion/(?P<code>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'DELETE') {
                            $allow[] = 'DELETE';
                            goto not_delete_rfd_configuracion;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_rfd_configuracion')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::deleteRfdConfiguracionAction',  '_format' => 'json',));
                    }
                    not_delete_rfd_configuracion:

                    // post_rfd_configuracion
                    if (preg_match('#^/api\\-consulta/web/rfdconfiguracion(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_post_rfd_configuracion;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'post_rfd_configuracion')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::postRfdConfiguracionAction',  '_format' => 'json',));
                    }
                    not_post_rfd_configuracion:

                }

                if (0 === strpos($pathinfo, '/api-consulta/t')) {
                    // get_topics
                    if (0 === strpos($pathinfo, '/api-consulta/topics') && preg_match('#^/api\\-consulta/topics(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_get_topics;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_topics')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getTopicsAction',  '_format' => 'json',));
                    }
                    not_get_topics:

                    // get_types
                    if (0 === strpos($pathinfo, '/api-consulta/types') && preg_match('#^/api\\-consulta/types(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_get_types;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_types')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getTypesAction',  '_format' => 'json',));
                    }
                    not_get_types:

                }

                // get_query
                if (0 === strpos($pathinfo, '/api-consulta/query') && preg_match('#^/api\\-consulta/query(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_get_query;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_query')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getQueryAction',  '_format' => 'json',));
                }
                not_get_query:

                // get_rfd
                if (0 === strpos($pathinfo, '/api-consulta/rfd') && preg_match('#^/api\\-consulta/rfd(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_get_rfd;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_rfd')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getRfdAction',  '_format' => 'json',));
                }
                not_get_rfd:

            }

            // nelmio_api_doc_index
            if (0 === strpos($pathinfo, '/api-docs') && preg_match('#^/api\\-docs(?:/(?P<view>[^/]++))?$#sD', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_nelmio_api_doc_index;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'nelmio_api_doc_index')), array (  '_controller' => 'Nelmio\\ApiDocBundle\\Controller\\ApiDocController::indexAction',  'view' => 'default',));
            }
            not_nelmio_api_doc_index:

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
