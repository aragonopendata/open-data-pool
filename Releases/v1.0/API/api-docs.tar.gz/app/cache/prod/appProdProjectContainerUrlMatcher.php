<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);

        // worker
        if (0 === strpos($pathinfo, '/worker') && preg_match('#^/worker/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'worker')), array (  '_controller' => 'ApiRest\\WorkerBundle\\Controller\\DefaultController::indexAction',));
        }

        if (0 === strpos($pathinfo, '/api')) {
            if (0 === strpos($pathinfo, '/api/web/configuracion')) {
                // get_listado_yammer
                if (0 === strpos($pathinfo, '/api/web/configuracion/listadoyammer') && preg_match('#^/api/web/configuracion/listadoyammer(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_get_listado_yammer;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_listado_yammer')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getListadoYammerAction',  '_format' => 'json',));
                }
                not_get_listado_yammer:

                // get_yammer
                if (0 === strpos($pathinfo, '/api/web/configuracion/yammer') && preg_match('#^/api/web/configuracion/yammer/(?P<nombre>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_get_yammer;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_yammer')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getYammerAction',  '_format' => 'json',));
                }
                not_get_yammer:

                // get_configuracion
                if (preg_match('#^/api/web/configuracion/(?P<nombre>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_get_configuracion;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_configuracion')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getConfiguracionAction',  '_format' => 'json',));
                }
                not_get_configuracion:

                // delete_configuracion
                if (preg_match('#^/api/web/configuracion/(?P<nombre>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_delete_configuracion;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_configuracion')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::deleteConfiguracionAction',  '_format' => 'json',));
                }
                not_delete_configuracion:

                // post_configuracion
                if (preg_match('#^/api/web/configuracion(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_post_configuracion;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'post_configuracion')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::postConfiguracionAction',  '_format' => 'json',));
                }
                not_post_configuracion:

            }

            if (0 === strpos($pathinfo, '/api/publicacion')) {
                if (0 === strpos($pathinfo, '/api/publicacion/esquema')) {
                    // get_listado_xml
                    if (0 === strpos($pathinfo, '/api/publicacion/esquema/listadoxml') && preg_match('#^/api/publicacion/esquema/listadoxml(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_get_listado_xml;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_listado_xml')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getListadoXmlAction',  '_format' => 'json',));
                    }
                    not_get_listado_xml:

                    // get_xml
                    if (0 === strpos($pathinfo, '/api/publicacion/esquema/xml') && preg_match('#^/api/publicacion/esquema/xml/(?P<nombre>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_get_xml;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_xml')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getXmlAction',  '_format' => 'json',));
                    }
                    not_get_xml:

                    // delete_esquema
                    if (preg_match('#^/api/publicacion/esquema/(?P<nombre>[^/\\.]++)(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'DELETE') {
                            $allow[] = 'DELETE';
                            goto not_delete_esquema;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_esquema')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::deleteEsquemaAction',  '_format' => 'json',));
                    }
                    not_delete_esquema:

                    // post_esquema
                    if (preg_match('#^/api/publicacion/esquema(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_post_esquema;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'post_esquema')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::postEsquemaAction',  '_format' => 'json',));
                    }
                    not_post_esquema:

                }

                // post_insert
                if (0 === strpos($pathinfo, '/api/publicacion/insert') && preg_match('#^/api/publicacion/insert(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_post_insert;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'post_insert')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::postInsertAction',  '_format' => 'json',));
                }
                not_post_insert:

                if (0 === strpos($pathinfo, '/api/publicacion/update')) {
                    // post_entities
                    if (0 === strpos($pathinfo, '/api/publicacion/update/Entities') && preg_match('#^/api/publicacion/update/Entities(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_post_entities;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'post_entities')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::postEntitiesAction',  '_format' => 'json',));
                    }
                    not_post_entities:

                    if (0 === strpos($pathinfo, '/api/publicacion/update/view')) {
                        // get_view_dc_type
                        if (0 === strpos($pathinfo, '/api/publicacion/update/viewdctype') && preg_match('#^/api/publicacion/update/viewdctype(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_get_view_dc_type;
                            }

                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'get_view_dc_type')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::getViewDcTypeAction',  '_format' => 'json',));
                        }
                        not_get_view_dc_type:

                        // post_view
                        if (preg_match('#^/api/publicacion/update/view(?:\\.(?P<_format>xml|json|html))?$#sD', $pathinfo, $matches)) {
                            if ($this->context->getMethod() != 'POST') {
                                $allow[] = 'POST';
                                goto not_post_view;
                            }

                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'post_view')), array (  '_controller' => 'ApiRest\\AodPoolBundle\\Controller\\AodPoolController::postViewAction',  '_format' => 'json',));
                        }
                        not_post_view:

                    }

                }

            }

            // nelmio_api_doc_index
            if (0 === strpos($pathinfo, '/api-docs') && preg_match('#^/api\\-docs(?:/(?P<view>[^/]++))?$#sD', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_nelmio_api_doc_index;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'nelmio_api_doc_index')), array (  '_controller' => 'Nelmio\\ApiDocBundle\\Controller\\ApiDocController::indexAction',  'view' => 'default',));
            }
            not_nelmio_api_doc_index:

        }

        // homepage
        if ('' === rtrim($pathinfo, '/')) {
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif (!in_array($this->context->getMethod(), array('HEAD', 'GET'))) {
                goto not_homepage;
            } else {
                return $this->redirect($rawPathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }
        not_homepage:

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
