<?php

namespace ApiRest\WorkerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ApiRestWorkerBundle extends Bundle
{
}
