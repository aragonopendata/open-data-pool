<?php
http://www.w3.org/ns/org#hasSite@http://www.w3.org/ns/org#siteAddress@http://www.w3.org/2006/vcard/ns#hasAddress@http://www.w3.org/2006/vcard/ns#locality='ABIEGO'